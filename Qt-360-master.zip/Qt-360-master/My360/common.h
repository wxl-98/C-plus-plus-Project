#ifndef COMMON_H
#define COMMON_H

#define __UNUSED(x)  (void)(x)

#endif // COMMON_H
